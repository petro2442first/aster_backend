<?php

return [
    'main' => '首页',
    'about' => '关于我们',
    'tariffs' => '关税计划',
    'faq' => 'FAQ',
    'contacts' => '联系我们',
    'login' => '登录',
    'register' => '注册'
];
