<?php

return [
    'main' => 'Home',
    'about' => 'About us',
    'tariffs' => 'Tariff plans',
    'faq' => 'FAQ',
    'contacts' => 'Contact us',
    'login' => 'Login',
    'register' => 'Register',
    'lang' => 'Language',
    'start' => 'Start'
];
