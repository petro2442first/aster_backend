<?php
return [
    'title' => 'Contact us',
    'c1' => 'Ask all questions immediately to us!',
    'c2' => 'Authorization, technical support',
    'c3' => 'Administrator',
    'c4' => 'Fill in the fields of the form and send a message:',
    'c5' => 'Send',
    'c6' => 'We will answer you in turn',
    'c7' => 'Тhe application has been submitted and will be reviewed on a first come, first served basis.',
    'c8' => 'Thank you!'
];
