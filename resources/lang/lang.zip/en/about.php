<?php
return [
    'title' => 'About Us',
    'p1' => '  Aster is a trading and investment company that recently
    started its activity, but has already managed to show a high
    coefficient of successful and profitable transactions for investors,
    entrusted the finances of our company.',
    'p2' => ' Aster`s staff consists of professional traders and
    effective managers with many years of experience
    financial and economic, as well as exchange activities. Experience
    work of employees of our company for at least twenty years.',
    'p3' => 'The difference between Aster and other trading and investment companies
    lies in the fact that all the actions of our employees are
    verified and professionally calculated algorithm of actions,
    thanks to which Aster shows the most efficient and
    financially profitable number of exchange transactions. The transaction data
    in turn, bring daily stable income to investors
    of our company, thereby increasing the capitalization of the
    company, which allows Aster investors to be financially
    confident in the future, despite daily fluctuations
    stock quotes.',
    'p4' => 'Aster - focused on long-term cooperation and
    guarantees investors the stability of accrual of interest on profits
    and timeliness of payments on deposits, as well as on all taken
    on investment obligations.',
    'p5' => '<span>Aster</span> is stability and financial independence
    every investor.',
    'p6' => '
    The Unique Investment Group looks forward to a long-term partnership on mutually beneficial terms.
    '
];
