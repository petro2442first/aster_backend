<?php
return [
    'welcome' => 'Aster is the best way to get your assets and finances in order!',
    'enter_info' => 'Enter your information'
];
