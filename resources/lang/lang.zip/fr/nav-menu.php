<?php

return [
    'main' => 'Accueil',
    'about' => 'A propos de nous',
    'tariffs' => 'Régime tarifaire',
    'faq' => 'FAQ',
    'contacts' => 'Nous contacter',
    'login' => 'Connexion',
    'register' => 'Inscription'
];
