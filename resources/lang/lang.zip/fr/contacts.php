<?php
return [
    'title' => 'Nous contacter',
    'c1' => 'Questions sur l`entreprise, conseils financiers',
    'c2' => 'Autorisation, assistance technique',
    'c3' => 'Administrateur',
    'c4' => 'Remplissez les champs du formulaire et envoyez un message :',
    'c5' => 'Envoyer',
    'c6' => 'Nous vous répondrons à tour de rôle',
    'c7' => 'Тhe application has been submitted and will be reviewed on a first come, first served basis.',
    'c8' => 'Merci !'
];
