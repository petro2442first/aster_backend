<?php

return [
    'main' => 'Home',
    'about' => 'Über uns',
    'tariffs' => 'Tarifpläne',
    'faq' => 'FAQ',
    'contacts' => 'Kontakt',
    'login' => 'Anmeldung',
    'register' => 'Registrieren',
    'lang' => 'Sprache',
    'start' => 'Start'
];
