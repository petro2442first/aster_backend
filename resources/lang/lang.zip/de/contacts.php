<?php
return [
    'title' => 'Kontakt',
    'c1' => 'Fragen zum Unternehmen, Finanzberatung',
    'c2' => 'Autorisierung, technische Unterstützung',
    'c3' => 'Verwalter',
    'c4' => 'Füllen Sie die Felder des Formulars aus und senden Sie eine Nachricht:',
    'c5' => 'Senden Sie',
    'c6' => 'Wir werden Ihnen der Reihe nach antworten',
    'c7' => 'Der Antrag wurde eingereicht und wird in der Reihenfolge des Eingangs geprüft.',
    'c8' => 'Ich danke Ihnen!'
];
