<?php
return [
    'verify' => 'Click this button to verify your e-mail'
];
