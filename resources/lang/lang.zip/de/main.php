<?php
return [
    'welcome' => 'Aster ist der beste Weg, um Ihr Vermögen und Ihre Finanzen in Ordnung zu bringen!',
    'enter_info' => 'Geben Sie Ihre Informationen ein'
];
