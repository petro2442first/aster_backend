<?php

return [
    'main' => 'Главная',
    'about' => 'О нас',
    'tariffs' => 'Тарифы',
    'faq' => 'FAQ',
    'contacts' => 'Контакты',
    'login' => 'Войти',
    'register' => 'Регистрация',
    'lang' => 'Язык',
    'start' => 'Начать'
];
